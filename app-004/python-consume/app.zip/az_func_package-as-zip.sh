
rm app.zip
zip -r app.zip ./*